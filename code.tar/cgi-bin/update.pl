#!$$perl_command$$
##############################################################################
# Update.pl                                                                  #
# Copyright 1997 Gregory A Greenman
# $Revision: 1.3 $
# $Date: 2003/02/26 07:35:13 $
##############################################################################

require "includes.pl";

require "$cgi_dir/update2.pl";

print "Location: $teamsurl\n\n";

