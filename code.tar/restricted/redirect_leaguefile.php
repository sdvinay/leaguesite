<?php 
# $Revision: 1.1 $
# $Date: 2003/03/03 03:23:21 $

require("$$_php_loc$$/utils.php");

$hdr = "Location: " . $LgOptions['leaguefileurl'];
header($hdr);
?>
