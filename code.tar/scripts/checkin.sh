#!/bin/sh

# $Revision: 1.1 $
# $Date: 2003/02/27 02:51:52 $

~/leaguesite/scripts/label.sh ~/leaguesite
