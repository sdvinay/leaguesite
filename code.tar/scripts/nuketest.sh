#!/bin/sh

# $Revision: 1.2 $
# $Date: 2003/02/26 07:36:04 $

rm -fr ~/trhl/cgi-bin/test
rm -fr ~/trhl/public_html/test

