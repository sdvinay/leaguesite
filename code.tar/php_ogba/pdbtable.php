<?

// $Revision$
// $Date$

// class PDBTable encapsulates the list of all the PDBs in the data store,
// providing Get and Set methods

class PDBTable
{
	var $explist;
	
	function PDBTable()
	{
		$this->explist = new ExpenseList();
		// don't use filter when generating because we might Write() back to file
		$this->explist->Generate(); 
	}
	
	function GetFrnPDBAmt($team, $year=$$season$$)
	{
		return $this->GetHelper($team, $year, "FPDB");
	}
	
	function GetDomPDBAmt($team, $year=$$season$$)
	{
		return $this->GetHelper($team, $year, "DPDB");
	}
	
	function GetHelper($team, $year, $type)
	{
		$tmfilter = new SimpleFilter("teamnum", $team);
		$yrfilter = new SimpleFilter("year", $year);
		$typefilter = new SimpleFilter("type", $type);
		
		$filter = new AndFilter(array($tmfilter,$yrfilter,$typefilter));
	
		$list = $this->explist->Find($filter);
		if(count($list) == 0)
		{
			return "";
		}
		else
		{
			list($dummy, $obj) = each($list);
			return $obj->amount;
		}
	}
	
	function SetFrnPDBAmt($team, $amount, $year=$$season$$)
	{
		return $this->SetHelper($team, $year, "FPDB", $amount);
	}
	
	function SetDomPDBAmt($team, $amount, $year=$$season$$)
	{
		return $this->SetHelper($team, $year, "DPDB", $amount);
	}
	
	function SetHelper($team, $year, $type, $amount)
	{
		$tmfilter = new SimpleFilter("teamnum", $team);
		$yrfilter = new SimpleFilter("year", $year);
		$typefilter = new SimpleFilter("type", $type);
		
		$filter = new AndFilter(array($tmfilter,$yrfilter,$typefilter));
	
		$list = $this->explist->Find($filter);
		
		// if we found one, update it
		if(count($list) > 0)
		{
			list($idx, $exp) = each($list);
			$this->explist->myArray[$idx]->amount = $amount;  // TODO don't access myArray directly
		} else
		{
			$exp = new Expense();
			$expnum = $this->explist->GetNewExpnum();
			$exp->Populate($expnum, $teamnum, $$season$$, $type, $amount, "");
			$this->explist->myArray[$expnum] = $exp;  // TODO don't access myArray directly
		}
		
		$this->explist->Write();
	}
	
}

?>