<?php

require_once("/home/vinay/trhl/public_html/ogba/utils.php"); 
require_once("/home/vinay/trhl/public_html/ogba/expenselist.php");
require_once("/home/vinay/trhl/public_html/ogba/teamlist.php");
require_once("/home/vinay/trhl/public_html/ogba/pdbtable.php");
ReadInCGI();

$pdbs = new PDBTable();
$tmList = new TeamList();

// if this is true, this will list the actual PDB values
// if false, it will just display "set" vs. "unset"
$bDisplayPDBs = false;

?>
<html>
<head>
  <title>Set PDBs</title>
  <link rel="stylesheet" href="http://trhl.doorstop.net/ogba/css/main.css" type="text/css">
</head>

<body>
<center><h2>Oscar Gamble Baseball Alliance</h2>
<h3>PDB status</h3>

<div class=alert>
Looking to set your PDB?<br>
Go here: <a href=http://trhl.doorstop.net/ogba/restricted/set_pdb.php>http://trhl.doorstop.net/ogba/restricted/set_pdb.php</a><br>
</div>

<table border='1'>
<tr><th>Team #</th><th>Team name</th><th>Domestic PDB</th><th>Foreign PDB</th></tr>
<?
$tmList->Reset();
while (list($teamnum, $teamObj) = $tmList->each())
{
	$dpdb = $pdbs->GetDomPDBAmt($teamnum);
	$fpdb = $pdbs->GetFrnPDBAmt($teamnum);
	$dpdb = ($dpdb === "") ? "unset" : ($bDisplayPDBs ? $dpdb : "set");
	$fpdb = ($fpdb === "") ? "unset" : ($bDisplayPDBs ? $fpdb : "set");
	?>
<tr><td><?=$teamnum?></td><td><?=$teamObj->teamname?></td><td><?=$dpdb?></td><td><?=$fpdb?></td></tr>
	<?
}
?>
</table>

</body>
</html>