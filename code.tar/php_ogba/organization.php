<?

// $Revision$
// $Date$

require_once("$$_php_loc$$/organization_classes.php");

// This file contains the organizational structure of the OGBA

// The idea is that organization_classes.php defines some
// generic classes for encapsulating an organization, while
// organization.php populates one instance of an Organization
// (and the rest of the hierarchy).  Each league using leaguesite
// can have its own organization.php.  By design, the actual
// method for populating the Organization is not defined.  Here
// we have actual code containing the data, just because that's
// easier than writing, say, an XML parser.


// Remember that we need to add the children to the parent from the
// bottom up, since PHP makes copies by default (so if we add a league
// to an org, then attempt to add a div to that league, it'll just add
// it to the local copy of the league, and not to the one owned by the org).

$org = new Organization();
$org->name="Three Run Homer League";
$org->abbr="TRHL";

$lgAm = new League();
$lgAm->name="American League";
$lgAm->abbr="AL";

$lgNat = new League();
$lgNat->name="National League";
$lgNat->abbr="NL";

$alw = new Division();
$alw->name = "West";
$alw->abbr = "ALW";
$alw->teamNumArray = array(107, 108, 109, 110, 111, 112);

$ale = new Division();
$ale->name = "East";
$ale->abbr = "ALE";
$ale->teamNumArray = array(101, 102, 103, 104, 105, 106);


$nlw = new Division();
$nlw->name = "West";
$nlw->abbr = "NLW";
$nlw->teamNumArray = array(207, 208, 209, 210, 211, 212);

$nle = new Division();
$nle->name = "East";
$nle->abbr = "NLE";
$nle->teamNumArray = array(201, 202, 203, 204, 205, 206);

$lgAm->divArray = array($ale, $alw);
$lgNat->divArray = array($nle, $nlw);

$org->lgArray = array($lgAm, $lgNat);

?>